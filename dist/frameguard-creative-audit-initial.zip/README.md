# FrameGuard AI – Creative Project Delivery Auditor

**Skill ID:** `frameguard-creative-audit`

FrameGuard AI is a UGREEN AI NAS skill that audits a creative project's deliverables against a client brief. It extracts structured requirements, searches the authorized NAS folder, matches assets, detects duplicates, and generates a professional audit report.

## Features
- Natural‑language brief parsing (`document_understanding`).
- Comprehensive file discovery (`file_search`).
- Photo index lookup for visual clues (`photo_search`).
- Duplicate detection (`duplicate_detection`).
- Evidence‑based requirement status (VERIFIED, CANDIDATE, MISSING, UNKNOWN).
- Optional safe organization of assets and report saving (user‑confirmed).

## Quick Start
1. Install the skill package (ZIP) via the UGREEN Skills Hub.
2. In the chat, say *"Audit my project"*.
3. Provide the brief (text or NAS path) and the project folder path.
4. Review the generated audit report and optionally approve organization actions.

All processing stays on‑device; no external data transmission occurs.

---

## Repository Layout
```
frameguard-creative-audit/
│   SKILL.md                 # Core skill manifest
│   README.md                # This file
│
└── references/
│   ├── capability-map.md
│   ├── workflow.md
│   ├── matching-rules.md
│   ├── report-template.md
│   ├── privacy-and-safety.md
│   └── validation-test-cases.md
│
└── submission/
│   ├── round1-answers.md
│   ├── round1-answers.pdf
│   ├── technical-architecture.md
│   ├── technical-validation-plan.md
│   ├── development-status.md
│   └── finalist-demo-script.md
│
└── dist/
    └── frameguard-creative-audit-initial.zip
```
